<?php

class Index_Controller extends Controller{

    public function __construct() {
		parent::__construct();
	}
	
	public function index() {
	
		// Load page template file
		$this->Load_View('index');
	
		// load CSS file
		$this->view->Set_CSS('public' . DS . 'css' . DS . 'style.css');
		// Set page title
		$this->view->Set_Site_Title( "MVC Calculator App Demo" );
		
		// HEADER
		$header = new View();
		$header->Assign('app_title', "MVC Calculator App Demo");
		$this->Assign('header', $header->Render('header', false));
		
		// FOOTER
		$footer = new View();
		$this->Assign('footer', $footer->Render('footer', false)); 
	
		
		// content string
		$content = "";
		
		$content_view = new View();
		$content .= $content_view->Render("index".DS."form", false);
		
	
		// if there is user input, calculate and pass it back to view
		if(isset($_POST['var1']) && is_numeric($_POST['var1']) && isset($_POST['var2']) && is_numeric($_POST['var2'])&& isset($_POST['operation'])){
		
			// clean 'operation' input
			$op = strtolower($_POST['operation']) == "add" ? "Add" : "Sub";
			
			$math = new Math_Model();
		
			$content_view = new View();
			$content_view->Assign("title", $op);
			$content_view->Assign("body", $_POST['var1'] . " <b>$op</b> " . $_POST['var2'] . " <b>is</b> " . $math->$op($_POST['var1'], $_POST['var2']));
			$content .= $content_view->Render("index".DS."index", false);
		
		
		}

		
		$this->Assign('content', $content); 
		
	}

}